﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NamespaceZeichenobjekt
{
    /// <summary>
    /// ParameterInput Klasse für String
    /// </summary>
    class StringParameterInput : ParameterInput
    {
        /// <summary>
        /// Konsturktor für einen String Input
        /// </summary>
        /// <param name="parName">Name des Parameters</param>
        public StringParameterInput(String parName)
        {
            Label label = new Label();
            if (parName != null)
                label.Text = parName + " (String)";
            else
                label.Text = "String";
            this._Labels.Add(label);

            TextBox field = new TextBox();
            field.Text = "...";
            this._Inputs.Add(field);
        }

        /// <summary>
        /// @see zeichenflaeche.parametervalues.ParameterValue#getValue()
        /// </summary>
        /// <returns>Wert des Parameters als object</returns>
        public override object GetValue()
        {
            return ((TextBox)this._Inputs[0]).Text;
        }
    }
}
