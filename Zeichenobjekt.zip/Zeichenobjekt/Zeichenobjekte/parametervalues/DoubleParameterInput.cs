﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NamespaceZeichenobjekt
{
    /// <summary>
    /// ParameterInput Klasse für Double
    /// </summary>
    class DoubleParameterInput : ParameterInput
    {

        /// <summary>
        /// Konsturktor für eine Double Input
        /// </summary>
        /// <param name="parName">Name des Parameters</param>
        public DoubleParameterInput(String parName)
        {
            System.Windows.Forms.Label label = new System.Windows.Forms.Label();
            if (parName != null)
                label.Text = parName + " (double)";
            else
                label.Text = "double / Double";
            this._Labels.Add(label);
            System.Globalization.NumberFormatInfo myDF = new System.Globalization.NumberFormatInfo();
            System.Windows.Forms.TextBox field = new NumTextBox();
            field.Text = "0" + myDF.NumberDecimalSeparator + "0";
            this._Inputs.Add(field);
        }

        /// <summary>
        /// @see zeichenflaeche.parametervalues.ParameterValue#getValue()
        /// </summary>
        /// <returns>Wert des Parameters als object</returns>
        public override object GetValue()
        {
            Double tmp = 0;
            if (!Double.TryParse(((System.Windows.Forms.TextBox)this._Inputs[0]).Text, out tmp))
                throw new System.ArgumentException("Nicht möglich Double Wert zu parsen!");
            return tmp;
        }
    }
}
