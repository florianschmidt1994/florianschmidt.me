﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using NamespaceZeichenobjekt.Zeichenobjekte;

namespace NamespaceZeichenobjekt
{
    /// <summary>
    /// ParameterInput Klasse für Arrays of Punkte
    /// </summary>
    class ArrayOfPunkteParameterInput : ParameterInput
    {
        /// <summary>
        /// Konsturktor für ein Arrays of Punkte
        /// </summary>
        /// <param name="parName">Name des Parameters</param>
        public ArrayOfPunkteParameterInput(String parName)
        {
            Label label = new Label();
            if (parName != null)
                label.Text = parName + " (X1; X2; ...)";
            else
                label.Text = "X1; X2; ...";
            this._Labels.Add(label);
            System.Globalization.NumberFormatInfo myDF = new System.Globalization.NumberFormatInfo();
            System.Windows.Forms.TextBox field = new ArrayTextBox();
            field.Text = "0" + myDF.NumberDecimalSeparator + "0; 0" + myDF.NumberDecimalSeparator + "0; 0" + myDF.NumberDecimalSeparator + "0";
            this._Inputs.Add(field);
            label = new Label();
            if (parName != null)
                label.Text = parName + " (Y1; Y2; ...)";
            else
                label.Text = "Y1; Y2; ...";
            this._Labels.Add(label);

            field = new ArrayTextBox();
            field.Text = "0" + myDF.NumberDecimalSeparator + "0; 0" + myDF.NumberDecimalSeparator + "0; 0" + myDF.NumberDecimalSeparator + "0";
            this._Inputs.Add(field);
        }

        /// <summary>
        /// @see zeichenflaeche.parametervalues.ParameterValue#getValue()
        /// </summary>
        /// <returns>Wert des Parameters als object</returns>
        public override object GetValue()
        {
            String textX = ((TextBox)this._Inputs[0]).Text;
            String textY = ((TextBox)this._Inputs[1]).Text;
            String[] numX = textX.Split(Char.Parse(";"));
            String[] numY = textY.Split(Char.Parse(";"));
            int n = Math.Min(numX.Length, numY.Length);
            Punkt[] ret = new Punkt[n];
            for (int i = 0; i < n; i++)
                ret[i] = new Punkt(Double.Parse(numX[i].Replace(',', '.')),
                    Double.Parse(numY[i].Replace(',', '.')));
            return ret;
        }
    }
}
