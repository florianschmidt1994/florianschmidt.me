﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NamespaceZeichenobjekt
{
    /// <summary>
    /// ParameterInput Klasse für Arrays of Double
    /// </summary>
    class ArrayOfDoubleParameterInput : ParameterInput
    {
        /// <summary>
        /// Konsturktor für ein Arrays of Double
        /// </summary>
        /// <param name="parName">Name des Parameters</param>
        public ArrayOfDoubleParameterInput(String parName)
        {
            this._ParName = parName;
            Label label = new Label();
            if (parName != null)
                label.Text = parName + " (Double, Double, ...)";
            else
                label.Text = "Double; Double; ...";
            this._Labels.Add(label);
            System.Globalization.NumberFormatInfo myDF = new System.Globalization.NumberFormatInfo();
            
            //neue ArrayTextBox -> Kontrolliert gleich Eingaben mit
            System.Windows.Forms.TextBox field = new ArrayTextBox();
            
            //Standardtext 
            field.Text = "0" + myDF.NumberDecimalSeparator + "0; 0" + myDF.NumberDecimalSeparator + "0; 0" + myDF.NumberDecimalSeparator + "0";
            this._Inputs.Add(field);
        }

        /// <summary>
        /// @see zeichenflaeche.parametervalues.ParameterValue#getValue()
        /// </summary>
        /// <returns>Wert des Parameters als object</returns>
        public override object GetValue()
        {
            try
            {
                //da nur ein Input Feld -> das an Stelle 0
                String text = ((TextBox)this._Inputs[0]).Text;

                //Teilen anhand der Semioklen -> Array
                String[] num = text.Split(Char.Parse(";"));

                //Konvertieren der String Teile in Double Values
                //wenn parsen schief geht, kommt eine Exception, die von try catch gefangen wird
                Double[] ret = new Double[num.Length];
                for (int i = 0; i < num.Length; i++)
                    ret[i] = Double.Parse(num[i].Replace(',', '.'));
                return ret;
            }
            catch
            {
                throw new ArgumentException("Fehler bei Eingabe von " + this._ParName);
            }
        }
    }
}
