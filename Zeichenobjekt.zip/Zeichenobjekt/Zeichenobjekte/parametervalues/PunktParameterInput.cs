﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NamespaceZeichenobjekt.Zeichenobjekte;

namespace NamespaceZeichenobjekt
{
    /// <summary>
    /// ParameterInput Klasse für Punkt
    /// </summary>
    class PunktParameterInput : ParameterInput
    {

        /// <summary>
        /// Konsturktor für einen Punkt Input
        /// </summary>
        /// <param name="parName">Name des Parameters</param>
        public PunktParameterInput(String parName)
        {
            System.Windows.Forms.Label label = new System.Windows.Forms.Label();
            if (parName != null)
                label.Text = parName + " X";
            else
                label.Text = "Punkt-X";
            this._Labels.Add(label);

            System.Globalization.NumberFormatInfo myDF = new System.Globalization.NumberFormatInfo();
            System.Windows.Forms.TextBox field = new NumTextBox();

            field.Text = "0" + myDF.NumberDecimalSeparator + "0";
            this._Inputs.Add(field);



            label = new System.Windows.Forms.Label();
            if (parName != null)
                label.Text = parName + " Y";
            else
                label.Text = "Punkt-Y";
            this._Labels.Add(label);

            myDF = new System.Globalization.NumberFormatInfo();
            field = new NumTextBox();

            field.Text = "0" + myDF.NumberDecimalSeparator + "0";
            this._Inputs.Add(field);
        }

        /// <summary>
        /// @see zeichenflaeche.parametervalues.ParameterValue#getValue()
        /// </summary>
        /// <returns>Wert des Parameters als object</returns>
        public override object GetValue()
        {
            Double tmp1 = 0;
            if (!Double.TryParse(((System.Windows.Forms.TextBox)this._Inputs[0]).Text, out tmp1))
                throw new System.ArgumentException("Nicht möglich Double Wert zu parsen!");
            Double tmp2 = 0;
            if (!Double.TryParse(((System.Windows.Forms.TextBox)this._Inputs[1]).Text, out tmp2))
                throw new System.ArgumentException("Nicht möglich Double Wert zu parsen!");
            return new Punkt(tmp1, tmp2);                        
        }
    }
}
