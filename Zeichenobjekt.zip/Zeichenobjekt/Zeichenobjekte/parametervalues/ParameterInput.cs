﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using NamespaceZeichenobjekt.Zeichenobjekte;

namespace NamespaceZeichenobjekt
{
    /// <summary>
    /// Parameter Input Klasse
    /// Abstrakte Oberklasse, die Labels und Inputfelder für spezifische Ausprägungen bereitstellt
    /// </summary>
    abstract class ParameterInput
    {

        /// <summary>
        /// Parameter Name
        /// </summary>
        protected String _ParName;

        /// <summary>
        /// Liste der Label - bei einfachen Datentypen nur ein Element enthalten bei komplexen Datentypen (z.B. Punkt) mehr
        /// </summary>
        protected List<System.Windows.Forms.Label> _Labels = new List<System.Windows.Forms.Label>();

        /// <summary>
        /// Liste der Input Elemente - bei einfachen Datentypen nur ein Element enthalten bei komplexen Datentypen (z.B. Punkt) mehr
        /// </summary>
        protected List<System.Windows.Forms.Control> _Inputs = new List<System.Windows.Forms.Control>();

        /// <summary>
        /// gibt Wert des Parameters als object zurück
        /// </summary>
        /// <returns>the Value from the fields</returns>
        public abstract object GetValue();

        /// <summary>
        /// Getter für Liste der Label
        /// </summary>
        /// <returns>die labels</returns>
        public List<System.Windows.Forms.Label> GetLabels()
        {
            return new List<System.Windows.Forms.Label>(this._Labels);
        }

        /// <summary>
        /// Getter für die Inputs
        /// </summary>
        /// <returns>inputs</returns>
        public List<System.Windows.Forms.Control> GetInputs()
        {
            return new List<System.Windows.Forms.Control>(this._Inputs);
        }

        /// <summary>
        /// Fügt Labelzur Eingabemaske hinzu
        /// </summary>
        /// <param name="parClass">Parameterklasse für die ParameterInput erzeugt werden soll</param>
        /// <param name="parName">optionaler Parametername</param>
        /// <returns>ParameterInput entsprechend parClass</returns>
        public static ParameterInput AddLabelInput(Type parClass, String parName) 
        {
            if (parClass.Equals(typeof(int)))
            {
                return new IntegerParameterInput(parName);
            }

            if (parClass.Equals(typeof(Double)) || parClass.Equals(typeof(double)))
            {
                return new DoubleParameterInput(parName);
            }
            if (parClass.Equals(typeof(Double[])) || parClass.Equals(typeof(double[])))
            {
                return new ArrayOfDoubleParameterInput(parName);
            }

            if (parClass.Equals(typeof(Punkt[])))
            {
                return new ArrayOfPunkteParameterInput(parName);
            }
            if (parClass.Equals(typeof(Punkt)))
            {
                return new PunktParameterInput(parName);
            }

            if (parClass.Equals(typeof(Color)))
            {
                return new ColorInput(parName);
            }

            if (parClass.Equals(typeof(String)))
            {
                return new StringParameterInput(parName);
            }
            throw new System.ArgumentException("Kenne keine M\u00f6glichkeit den Typ '" + parClass.ToString() + "' zu erzeugen.");
        }
    }
}
