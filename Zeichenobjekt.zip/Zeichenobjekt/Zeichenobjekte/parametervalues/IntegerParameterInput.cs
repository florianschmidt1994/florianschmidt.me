﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NamespaceZeichenobjekt
{
    /// <summary>
    /// ParameterInput Klasse für Integer
    /// </summary>
    class IntegerParameterInput : ParameterInput
    {

        /// <summary>
        /// Konsturktor für eine Integer Input
        /// </summary>
        /// <param name="parName">Name des Parameters</param>
        public IntegerParameterInput(String parName)
        {
            System.Windows.Forms.Label label = new System.Windows.Forms.Label();
            if (parName != null)
                label.Text = parName + " (int)";
            else
                label.Text = "int / Integer";
            this._Labels.Add(label);

            System.Globalization.NumberFormatInfo myDF = new System.Globalization.NumberFormatInfo();
            System.Windows.Forms.TextBox field = new NumTextBox();

            field.Text = "0";
            this._Inputs.Add(field);
        }

        /// <summary>
        /// @see zeichenflaeche.parametervalues.ParameterValue#getValue()
        /// </summary>
        /// <returns>Wert des Parameters als object</returns>
        public override object GetValue()
        {
            int tmp = 0;
            int.TryParse(((System.Windows.Forms.TextBox)this._Inputs[0]).Text, out tmp);
            return tmp;
        }
    }
}
