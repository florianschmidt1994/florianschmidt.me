﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NamespaceZeichenobjekt
{
    /// <summary>
    /// ParameterInput Klasse für Farbauswahl
    /// </summary>
    class ColorInput : ParameterInput
    {
        /// <summary>
        /// Buttonfarbe -> zeigt die aktuelle Auswahl an
        /// </summary>
        Button _BtnFarbe;

        /// <summary>
        /// Colordialog zur Farbauswahl
        /// </summary>
        private System.Windows.Forms.ColorDialog colorDialog;

        /// <summary>
        /// Konsturktor für eine Farbauwswahl
        /// </summary>
        /// <param name="parName">Name des Parameters</param>
        public ColorInput(String parName)
        {
            colorDialog = new System.Windows.Forms.ColorDialog();
            Label label = new Label();
            if (parName != null)
                label.Text = parName + "  w\u00e4hlen";
            else
                label.Text = "Farbe w\u00e4hlen";
            this._Labels.Add(label);
            this._BtnFarbe = new Button();
            this._BtnFarbe.Name = "Farbe";
            //Standardauswahl an Farbe: Schwarz - könnte man auch mit = Color.Black realisieren
            this._BtnFarbe.BackColor = Color.FromArgb(0, 0, 0);
            this._BtnFarbe.ForeColor = Color.FromArgb(255, 255, 255);
            //Definition des Ereignisses, was beim klicken des Farbauswahlbuttons passieren soll
            this._BtnFarbe.Click += delegate(System.Object o, System.EventArgs e)
            {
                //öffne Colordialog
                if (colorDialog.ShowDialog() == DialogResult.OK)
                {
                    //schreibe ausgewählte Farbe auf Button und bereite damit Rückgabewert vor
                    this._BtnFarbe.BackColor = colorDialog.Color;
                }
            };
            this._Inputs.Add(this._BtnFarbe);
        }

        /// <summary>
        /// @see zeichenflaeche.parametervalues.ParameterValue#getValue()
        /// </summary>
        /// <returns>Wert des Parameters als object</returns>
        public override object GetValue()
        {
            return this._BtnFarbe.BackColor;
        }
    }
}
