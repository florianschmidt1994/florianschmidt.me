﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NamespaceZeichenobjekt.Zeichenobjekte;

namespace NamespaceZeichenobjekt
{
    /// <summary>
    /// Listbox auf der Zeichenfläche, die die Zeichenobjekte beherbergt
    /// </summary>
    class StringListModel : System.Windows.Forms.ListBox
    {

        /// <summary>
        /// Liste mit Eintägen
        /// </summary>
        private List<String> _Model = new List<String>();

        /// <summary>
        /// Getter für ein bestimmtes Element an einem gegebenen Index
        /// </summary>
        /// <param name="index">Index an dem das Element aufgegriffen werden soll</param>
        /// <returns>Element an übergebenem Index</returns>
        public String GetElementAt(int index)
        {
            if (index < 0 || index > this._Model.Count || this._Model.Count == 0)
                return null;
            return this._Model[index];
        }

        /// <summary>
        /// Getter für die Listengröße
        /// </summary>
        /// <returns>Anzahl an Elementen in Liste</returns>
        public int GetSize()
        {
            return this._Model.Count;
        }

        /// <summary>
        /// Prüft, ob ein Element in der Liste enthalten ist
        /// </summary>
        /// <param name="element">Name des zu findenden Elementes</param>
        /// <returns>true, wenn Element enthalten ist</returns>
        public Boolean ContainsElement(String element)
        {
            return this._Model.Contains(element);
        }

        /// <summary>
        /// Fügt Element hinzu
        /// </summary>
        /// <param name="element">Name des Elementes</param>
        /// <returns>true, wenn erfolgreich</returns>
        public Boolean AddElement(String element)
        {
            if (element == null || this._Model.Contains(element))
                return false;
            this._Model.Add(element);
            this.Items.Add(element);
            return true;
        }

        /// <summary>
        /// entfernt Element von Liste
        /// </summary>
        /// <param name="element">Name des zu entfernenden Elementes</param>
        /// <returns>true, wenn erfolgreich</returns>
        public Boolean RemoveElement(String element)
        {
            if (element == null || !this._Model.Contains(element))
                return false;

            int idx = this._Model.IndexOf(element);
            this._Model.Remove(element);
            this.Items.Remove(element);

            return true;
        }
    }

}