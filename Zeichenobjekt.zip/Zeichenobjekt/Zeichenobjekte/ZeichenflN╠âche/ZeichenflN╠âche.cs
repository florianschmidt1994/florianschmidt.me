﻿using NamespaceZeichenobjekt.Zeichenobjekte;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NamespaceZeichenobjekt
{
    /// <summary>
    /// Form - Zeichenfläche 
    /// Fenster mit Buttns, einer Liste und der Zeichenfläche ansich
    /// </summary>
    public partial class Zeichenfläche : Form
    {
        /// <summary>
        /// Map mit allen Zeichenobjekten - Schlüssel ist die Bezeichnung der Zeichenobjekte
        /// </summary>
        Dictionary<String, ZeichenObjekt> _ZObjekte = new Dictionary<String, ZeichenObjekt>();
        
        /// <summary>
        /// die Graphik auf der die Zeichenobjekte dargestellt werden
        /// </summary>
        Graphics _Graph;

        /// <summary>
        /// Konstruktor für den Zeichenflächendialog
        /// </summary>
        public Zeichenfläche()
        {

            InitializeComponent();
            FlowLayoutPanel_graph_Resize(this, null);
            //legt Graphic an, setzt Hintergrund, stellt alle (hier noch nicht vorhandenen Zeichenobjekte dar.
            this.Refresh();
        }

        /// <summary>
        /// legt neues Zeichenobjekt an
        /// Reihenfolge:
        /// -> Objektauswahl
        /// -> Konstruktorenauswahl
        /// -> Parameterinput
        /// </summary>
        /// <param name="sender">Wird nur von Button aufgerufen</param>
        /// <param name="e">Wird nur von Button aufgerufen</param>
        private void Btn_New_Click(object sender, EventArgs e)
        {
            try
            {
                //lege Objektauswahldialog an
                Objektauswahl oausw = new Objektauswahl();
                oausw.ShowDialog(this);
                //Da Dialog -> Modal...
                //Aufruf ShowDialog kehrt erst zurück, wenn alle unterlagerten Fenster geschlossen wurden

                //wenn alle Eingaben korrekt abgeschlossen wurden und die Eingaben valide sind...
                if (oausw.GetIsInputValid())
                {
                    Konstruktorauswahl kwahl = oausw.GetKonstruktorauswahl();
                    if (kwahl.GetIsInputValid())
                    {

                        ParameterValueDialog pvd = kwahl.GetParameterValueDialog();
                        if (pvd.GetIsInputValid())
                        {
                            //...geht es weiter mit dem eigentlichen anlegen Des Zeichenobjekts
                            String name = pvd.GetTypedName();
                            String setName = name;
                            int i = 0;
                            //wenn schon Zeichenobjekte vorhanden sind, muss überprüft werden, ob schon einmal der Name für das Zeichenobjekt vergeben wurde
                            if (_ZObjekte.Count != 0)
                                while (_ZobjektListModel.ContainsElement(setName))
                                {
                                    //wenn ja, dann wird eine Zahl hinzugefügt
                                    setName = name + i++;
                                }

                            Object[] parValues = pvd.GetParameterValues();

                            ZeichenObjekt zo = null;
                            //hier wird das eigentliche Zeichenobjekt angelegt.
                            //der Konstruktor wird gesucht und mit Invoke aufgerufen
                            try
                            {
                                zo = (ZeichenObjekt)pvd.GetConstructor().Invoke(parValues);
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show(ex.InnerException.Message);
                                return;
                            }
                            //wurde ein Zeichenobjekt erstellt, dann wird es zur zObjekt Liste hinzugefügt, 
                            //dem zobjektListModel (linke ListBox) hinzugefügt
                            // und die Zeichenfläche wird neu dargestellt
                            if (zo != null)
                            {
                                this._ZObjekte.Add(setName, zo);
                                _ZobjektListModel.AddElement(setName);
                                Repaint();
                            }
                        }
                    }
                }
            }
            catch (ArgumentException ae)
            {
                MessageBox.Show(ae.Message);
            }

        }

        /// <summary>
        /// ruft den Drehen Dialoh auf und führt eine Drehung der ausgewählten Objekte durch
        /// </summary>
        /// <param name="sender">Wird nur von Button aufgerufen</param>
        /// <param name="e">Wird nur von Button aufgerufen</param>
        private void BtnTurn_Click(object sender, EventArgs e)
        {
            List<ZeichenObjekt> markierte = GetMarkierteZO();
            if (markierte.Count == 0)
            {
                const string message = "Kein Objekt markiert!";
                const string caption = "Drehen Dialog";
                var result = MessageBox.Show(message, caption, MessageBoxButtons.OK, MessageBoxIcon.Question);
                return;
            }
            //Modaler Drehen Dialog
            DrehDialog dd = new DrehDialog();
            dd.ShowDialog();
            //kehrt erst zurück, wenn Dialog geschlossen wurde

            if (dd.GetIsInputValid())
            {
                //Dreht jedes der markierten Objekte
                foreach (ZeichenObjekt zo in markierte)
                    zo.Drehen(new Punkt(dd.GetXZentrum(), dd.GetYZentrum()), Math.PI * dd.GetDrehWinkel() / 180);
                //Zeichenfläche wird neu dargestellt
                Repaint();
            }
        }

        /// <summary>
        /// leert Graph, zeichnet alle ZeichenObjekte in zObjekte neu
        /// </summary>
        private void Repaint()
        {
            _Graph.Clear(Color.White);
            foreach (System.Collections.Generic.KeyValuePair<string, ZeichenObjekt> zo in _ZObjekte)
                zo.Value.Darstellen(_Graph);
        }

        /// <summary>
        /// Getter für die Liste aller markierten ZeichenObjekte
        /// </summary>
        /// <returns>Liste aller markierten ZeichenObjekte</returns>
        private List<ZeichenObjekt> GetMarkierteZO()
        {
            List<ZeichenObjekt> markierte = new List<ZeichenObjekt>();


            foreach (int i in this._ZobjektListModel.SelectedIndices)
            {
                String s = this._ZobjektListModel.GetElementAt(i);
                ZeichenObjekt zo = _ZObjekte[s];
                markierte.Add(zo);

            }
            return markierte;
        }

        /// <summary>
        /// Getter für die Liste der Namen aller markierten ZeichenObjekte
        /// </summary>
        /// <returns>List der Namen aller markierten ZeichenObjekte</returns>
        private List<String> GetMarkierteEl()
        {
            List<String> markierte = new List<String>();
            foreach (int i in this._ZobjektListModel.SelectedIndices)
            {
                String s = this._ZobjektListModel.GetElementAt(i);
                markierte.Add(s);
            }
            return markierte;
        }

        /// <summary>
        /// ruft den VerschiebenDialog auf
        /// </summary>
        /// <param name="sender">Wird nur von Button aufgerufen</param>
        /// <param name="e">Wird nur von Button aufgerufen</param>
        private void BtnMove_Click(object sender, EventArgs e)
        {
            List<ZeichenObjekt> markierte = GetMarkierteZO();
            if (markierte.Count == 0)
            {
                const string message = "Kein Objekt markiert!";
                const string caption = "Verschieben Dialog";
                var result = MessageBox.Show(message, caption, MessageBoxButtons.OK, MessageBoxIcon.Question);
                return;
            }
            //Modaler Dialog
            VerschiebenDialog md = new VerschiebenDialog();
            md.ShowDialog();
            //kehrt erst wieder zurück, wenn Dialog geschlossen wurde
            if (md.GetIsInputValid())
            {
                foreach (ZeichenObjekt zo in markierte)
                    zo.Verschieben(md.GetDX(), md.GetDY());
                Repaint();
            }
        }

        /// <summary>
        /// ruft den SkalierenDialog auf
        /// </summary>
        /// <param name="sender">Wird nur von Button aufgerufen</param>
        /// <param name="e">Wird nur von Button aufgerufen</param>
        private void Btn_Scale_Click(object sender, EventArgs e)
        {
            List<ZeichenObjekt> markierte = GetMarkierteZO();
            if (markierte.Count == 0)
            {
                const string message = "Kein Objekt markiert!";
                const string caption = "Strecken Dialog";
                var result = MessageBox.Show(message, caption, MessageBoxButtons.OK, MessageBoxIcon.Question);
                return;
            }
            //Modaler Dialog
            StreckenDialog sd = new StreckenDialog();
            sd.ShowDialog();
            //kehrt erst wieder zurück, wenn Dialog geschlossen wurde
            if (sd.GetIsInputValid())
            {
                foreach (ZeichenObjekt zo in markierte)
                    zo.Strecken(new Punkt(sd.GetXZentrum(), sd.GetYZentrum()), sd.GetFaktor());
                Repaint();
            }
        }

        /// <summary>
        /// Löscht alle markierten ZeichenObjekte - Ohne Rückfrage
        /// </summary>
        /// <param name="sender">Wird nur von Button aufgerufen</param>
        /// <param name="e">Wird nur von Button aufgerufen</param>
        private void Btn_delete_Click(object sender, EventArgs e)
        {
            List<String> markierte = GetMarkierteEl();
            if (markierte.Count == 0)
            {
                const string message = "Kein Objekt markiert!";
                const string caption = "Löschen Dialog";
                var result = MessageBox.Show(message, caption, MessageBoxButtons.OK, MessageBoxIcon.Question);
                return;
            }
            foreach (string s in markierte)
            {
                _ZObjekte.Remove(s);
                _ZobjektListModel.RemoveElement(s);

            }
            Repaint();
        }

        /// <summary>
        /// Wenn die Fenstergröße verändert wird, verändert sich auch die Größe des flowLayoutPanel_graph
        /// damit wird ein neuzeichnen des graphen nötig
        /// hier wird repaint aufgerufen
        /// </summary>
        /// <param name="sender">Wird nur von GUI aufgerufen</param>
        /// <param name="e">Wird nur von GUI aufgerufen</param>
        private void FlowLayoutPanel_graph_Resize(object sender, EventArgs e)
        {
            _Graph = flowLayoutPanel_graph.CreateGraphics();
            Repaint();
        }
    }
}
