﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NamespaceZeichenobjekt
{    
    /// <summary>
    /// Konstruktorauswahldialog, welcher von Form erbt
    /// </summary>
    public partial class Konstruktorauswahl : Form
    {
        /// <summary>
        /// Unterdialog für Parametereingabe
        /// </summary>
        private ParameterValueDialog _Parmvgld;

        /// <summary>
        /// welcher Konstruktoren hier dargestellt werden sollen
        /// </summary>
        private System.Reflection.ConstructorInfo[] _Constructors;

        /// <summary>
        /// wurde der Dialog erfolgreich beendet?
        /// </summary>
        protected Boolean _IsInputValid;

        /// <summary>
        /// Konsturktor für den Dialog,
        /// liest alle Konstruktoren des übergebenen Typs aus und stellt diese in einer Itembox dar
        /// </summary>
        /// <param name="t">Objekttyp</param>
        public Konstruktorauswahl(System.Type t)
        {
            InitializeComponent();
            this._IsInputValid = false;
            //leere Anzeige
            listBox1.Items.Clear();

            //Konsstruktoren von gegebener Klasse auslesen
            this._Constructors = t.GetConstructors();

            //Iteriere durch alle zuvor ermittelten Konstruktoren und lese Parametersignatur aus
            foreach (System.Reflection.ConstructorInfo c in this._Constructors)
            {
                String paramlist = "";
                System.Reflection.ParameterInfo[] parameters = c.GetParameters();
                foreach (System.Reflection.ParameterInfo p in parameters)
                {
                    paramlist += p.ParameterType.Name + " " + p.Name + " ";
                }
                listBox1.Items.Add(paramlist);
            }
        }

        /// <summary>
        /// erstelle ParameterValueDialog für gegebeben Konstruktor und Blende dieses Fenster wieder aus
        /// </summary>
        /// <param name="sender">Wird nur von Button aufgerufen</param>
        /// <param name="e">Wird nur von Button aufgerufen</param>
        private void Btn_Weiter_Click(object sender, EventArgs e)
        {
            int i = listBox1.SelectedIndex;
            this._Parmvgld = new ParameterValueDialog(this._Constructors[i]);
            this._Parmvgld.ShowDialog();
            this._IsInputValid = true;
            this.Visible = false;
        }
        
        /// <summary>
        /// bricht Eingabe ab und kehrt zu vorherigem Dialog zurück
        /// </summary>
        /// <param name="sender">Wird nur von Button aufgerufen</param>
        /// <param name="e">Wird nur von Button aufgerufen</param>
        private void Btn_cancel_Click(object sender, EventArgs e)
        {
            this._IsInputValid = false;
            this.Visible = false;
        }

        public ParameterValueDialog GetParameterValueDialog()
        {
            return this._Parmvgld;
        }

        /// <summary>
        /// Getter für IsInputValid
        /// </summary>
        /// <returns>wenn Eingabe valide -> true</returns>
        public Boolean GetIsInputValid()
        {
            return this._IsInputValid;
        }

    }
}
