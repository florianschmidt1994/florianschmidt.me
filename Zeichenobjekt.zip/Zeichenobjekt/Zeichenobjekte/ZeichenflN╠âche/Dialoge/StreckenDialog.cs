﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Input;
using NamespaceZeichenobjekt;

namespace NamespaceZeichenobjekt
{
    /// <summary>
    /// Streckendialog, welcher von Form erbt
    /// </summary>
    public partial class StreckenDialog : Form
    {
        /// <summary>
        /// x-Koordinate des Punktes von dem gestreckt werden soll
        /// </summary>
        protected double _XZentrum;

        //y-Koordinate des Punktes von dem gestreckt werden soll
        protected double _YZentrum;

        /// <summary>
        /// Faktor um den gestreckt werden soll
        /// </summary>
        protected double _Faktor;

        /// <summary>
        /// Eingaben alle gültig und Dialog abgeschlossen?
        /// </summary>
        protected Boolean _IsInputValid;

        /// <summary>
        /// Konstruktor für den Dialog
        /// </summary>
        public StreckenDialog()
        {
            InitializeComponent();
        }

        /// <summary>
        /// nimmt Parameter entgegen und lässt ausgewähltes Zeichenobjekt strecken
        /// </summary>
        /// <param name="sender">Wird nur von Button aufgerufen</param>
        /// <param name="e">Wird nur von Button aufgerufen</param>
        private void Btn_OK_Click(object sender, EventArgs e)
        {
            try
            {
                this._XZentrum = Double.Parse(this.textBox_xKoordinate.Text.Replace(',', '.'));
                this._YZentrum = Double.Parse(this.textBox_yKoordinate.Text.Replace(',', '.'));
                this._Faktor = Double.Parse(this.textBox_Faktor.Text.Replace(',', '.'));
                if (this._Faktor <= 0.0)
                {
                    this._IsInputValid = false;
                    return;
                }
                this._IsInputValid = true;
                this.Visible = false;
            }
            catch
            {
                this._IsInputValid = false;
            }
        }

        /// <summary>
        /// bricht Eingabe ab und kehrt zu vorherigem Dialog zurück
        /// </summary>
        /// <param name="sender">Wird nur von Button aufgerufen</param>
        /// <param name="e">Wird nur von Button aufgerufen</param>
        private void Btn_Cancel_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            this._IsInputValid = false;
        }

        /// <summary>
        /// Getter für die x-Koordinate
        /// </summary>
        /// <returns>x-Koordinate des Strecken Zentrums</returns>
        public double GetXZentrum()
        {
            return this._XZentrum;
        }

        /// <summary>
        /// Getter für die y-Koordinate
        /// </summary>
        /// <returns>y-Koordinate des Strecken Zentrums</returns>
        public double GetYZentrum()
        {
            return this._YZentrum;
        }

        /// <summary>
        /// Getter für den Streck-Faktor
        /// </summary>
        /// <returns>Faktor um den gestreckt werden soll</returns>
        public double GetFaktor()
        {
            return this._Faktor;
        }

        /// <summary>
        /// Getter für IsInputValid
        /// </summary>
        /// <returns>wenn Eingabe valide -> true</returns>
        public Boolean GetIsInputValid()
        {
            return this._IsInputValid;
        }
    }
}
