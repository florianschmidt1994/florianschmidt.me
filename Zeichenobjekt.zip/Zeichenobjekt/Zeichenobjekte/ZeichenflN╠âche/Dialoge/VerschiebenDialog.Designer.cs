﻿namespace NamespaceZeichenobjekt
{
    partial class VerschiebenDialog
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btn_Cancel = new System.Windows.Forms.Button();
            this.btn_OK = new System.Windows.Forms.Button();
            this.textBox_yRichtung = new NumTextBox();
            this.textBox_xRichtung = new NumTextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btn_Cancel
            // 
            this.btn_Cancel.Location = new System.Drawing.Point(134, 65);
            this.btn_Cancel.Name = "btn_Cancel";
            this.btn_Cancel.Size = new System.Drawing.Size(75, 23);
            this.btn_Cancel.TabIndex = 4;
            this.btn_Cancel.Text = "Cancel";
            this.btn_Cancel.UseVisualStyleBackColor = true;
            this.btn_Cancel.Click += new System.EventHandler(this.Btn_Cancel_Click);
            // 
            // btn_OK
            // 
            this.btn_OK.Location = new System.Drawing.Point(53, 65);
            this.btn_OK.Name = "btn_OK";
            this.btn_OK.Size = new System.Drawing.Size(75, 23);
            this.btn_OK.TabIndex = 3;
            this.btn_OK.Text = "OK";
            this.btn_OK.UseVisualStyleBackColor = true;
            this.btn_OK.Click += new System.EventHandler(this.Btn_OK_Click);
            // 
            // textBox_yRichtung
            // 
            this.textBox_yRichtung.Location = new System.Drawing.Point(163, 35);
            this.textBox_yRichtung.Name = "textBox_yRichtung";
            this.textBox_yRichtung.Size = new System.Drawing.Size(100, 20);
            this.textBox_yRichtung.TabIndex = 2;
            this.textBox_yRichtung.Text = "0,0";
            // 
            // textBox_xRichtung
            // 
            this.textBox_xRichtung.Location = new System.Drawing.Point(163, 12);
            this.textBox_xRichtung.Name = "textBox_xRichtung";
            this.textBox_xRichtung.Size = new System.Drawing.Size(100, 20);
            this.textBox_xRichtung.TabIndex = 1;
            this.textBox_xRichtung.Text = "0,0";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 42);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(58, 13);
            this.label2.TabIndex = 4;
            this.label2.Text = "y-Richtung";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 20);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(58, 13);
            this.label1.TabIndex = 5;
            this.label1.Text = "x-Richtung";
            // 
            // VerschiebenDialog
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(284, 98);
            this.Controls.Add(this.btn_Cancel);
            this.Controls.Add(this.btn_OK);
            this.Controls.Add(this.textBox_yRichtung);
            this.Controls.Add(this.textBox_xRichtung);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "VerschiebenDialog";
            this.Text = "VerschiebenDialog";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btn_Cancel;
        private System.Windows.Forms.Button btn_OK;
        private System.Windows.Forms.TextBox textBox_yRichtung;
        private System.Windows.Forms.TextBox textBox_xRichtung;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
    }
}