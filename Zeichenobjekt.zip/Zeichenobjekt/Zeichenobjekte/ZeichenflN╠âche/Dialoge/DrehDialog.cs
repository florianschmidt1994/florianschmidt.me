﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using NamespaceZeichenobjekt;

namespace NamespaceZeichenobjekt
{
    /// <summary>
    /// Drehdialog, welcher von Form erbt
    /// </summary>
    public partial class DrehDialog : Form
    {
        /// <summary>
        /// x-Koordinate des Drehpunktes
        /// </summary>
        protected double _XZentrum;

        /// <summary>
        /// y-Koordinate des Drehpunktes
        /// </summary>
        protected double _YZentrum;

        /// <summary>
        /// Drehwinkel
        /// </summary>
        protected double _DrehWinkel;

        /// <summary>
        /// wenn Eingaben OK sind -> true
        /// </summary>
        protected Boolean _InputValid;

        /// <summary>
        /// Konstruktor für den DrehDialog, Initialisiert alle Eingabefelder
        /// </summary>
        public DrehDialog()
        {
            InitializeComponent();
        }

        /// <summary>
        /// überprüft eingaben, wenn Valide -> Dialog ausblenden -> Rückkehr in Zeichenfläche
        /// </summary>
        /// <param name="sender">Wird nur von Button aufgerufen</param>
        /// <param name="e">Wird nur von Button aufgerufen</param>
        private void Btn_OK_Click(object sender, EventArgs e)
        {
            try
            {
                this._XZentrum = Double.Parse(textBox_xKoordinate.Text.Replace(',', '.'));
                this._YZentrum = Double.Parse(textBox_yKoordinate.Text.Replace(',', '.'));
                this._DrehWinkel = Double.Parse(textBox_Winkel.Text.Replace(',', '.'));
                this._InputValid = true;
                this.Visible = false;
            }
            catch
            {
                this._InputValid = false;
            }
        }

        /// <summary>
        /// bricht Eingabe ab und kehrt zu vorherigem Dialog zurück
        /// </summary>
        /// <param name="sender">Wird nur von Button aufgerufen</param>
        /// <param name="e">Wird nur von Button aufgerufen</param>
        private void Btn_Cancel_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            this._InputValid = false;
        }
        
        /// <summary>
        /// Getter für die x-Koordinate des Drehpunktes
        /// </summary>
        /// <returns>die x-Koordinate</returns>
        public double GetXZentrum()
        {
            return this._XZentrum;
        }

        /// <summary>
        /// Getter für die y-Koordinate des Drehpunktes
        /// </summary>
        /// <returns>die y-Koordinate</returns>
        public double GetYZentrum()
        {
            return this._YZentrum;
        }

        /// <summary>
        /// Getter für den eingegebenen Drehwinkel
        /// </summary>
        /// <returns>Drehwinkel</returns>
        public double GetDrehWinkel()
        {
            return this._DrehWinkel;
        }

        /// <summary>
        /// Getter für IsInputValid
        /// </summary>
        /// <returns>wenn Eingabe valide -> true</returns>
        public Boolean GetIsInputValid()
        {
            return this._InputValid;
        }
    }
}
