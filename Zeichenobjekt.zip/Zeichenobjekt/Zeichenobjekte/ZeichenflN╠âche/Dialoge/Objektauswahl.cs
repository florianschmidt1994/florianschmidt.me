﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using NamespaceZeichenobjekt.Zeichenobjekte;

namespace NamespaceZeichenobjekt
{
    /// <summary>
    /// Klasse für die Auswahl der möglichen Objekte die angezeigt werden können 
    /// liest alle Zeichenobjektklassen aus und gibt diese in Auswahlbox aus
    /// </summary>
    public partial class Objektauswahl : Form
    {
        /// <summary>
        /// Unterfenster für Auswahl der Konstruktoren
        /// </summary>
        private Konstruktorauswahl _KWahl;

        /// <summary>
        /// Wurde der Dialog erfolgreich abgeschlossen?
        /// </summary>
        private Boolean _IsInputValid;

        /// <summary>
        /// Konstruktor für den Dialog
        /// liest alle Typen aus und listet diese in einer Itembox
        /// </summary>
        public Objektauswahl()
        {
            InitializeComponent();
            this._IsInputValid = false;
            listBox1.Items.Clear();

            /*
            * Reflection von Zeichenobjekt Klassen
            */
            Assembly exe = Assembly.GetAssembly(this.GetType());
            
            // lese alle Typen aus
            System.Type[] types = exe.GetTypes();

            // beschränke Auswahl auf ZeichenObjekte
            System.Type zoType = exe.GetType("NamespaceZeichenobjekt.Zeichenobjekte.ZeichenObjekt");
            
            Int16 i = 0;
            List<Type> zos = new List<Type>();
            //Iteriere durch Klassen, füge relevante Klassen in Liste und listBox ein
            foreach (System.Type t in types)
            {
                i++;
                Type tt = t.BaseType;

                //betrachte auch Unterklassen der Objekte und gib diese - wenn nötig - aus
                while (tt != null)
                {
                    if (tt.Equals(zoType))
                    {
                        //nur nicht Abstrakte Klassen werden aufgenommen -> andere können ja ohnehin nicht angelegt werden
                        if (!t.IsAbstract)
                        {
                            zos.Add(t);
                            listBox1.Items.Add(t.FullName);
                        }
                        break;
                    }
                    tt = tt.BaseType;
                }
            }
        }

        /// <summary>
        /// gibt Unterfenster zurück
        /// </summary>
        /// <returns>Konstruktorenauswahldialog</returns>
        public Konstruktorauswahl GetKonstruktorauswahl()
        {
            return this._KWahl;
        }

        /// <summary>
        /// nimmt ausgewähltes Objekt und lässt Konstruktoren anzeigen
        /// </summary>
        /// <param name="sender">Wird nur von Button aufgerufen</param>
        /// <param name="e">Wird nur von Button aufgerufen</param>
        private void Btn_Weiter_Click(object sender, EventArgs e)
        {
            //liest ausgewähtes Zeichenobjekt aus
            String nameOfZeichenobjekt = listBox1.SelectedItem.ToString();

            //ermittelt Klasse zu ausgewhähltem Zeichenobjekt (String -> Klasse)
            Assembly exe = Assembly.GetAssembly(this.GetType());
            System.Type[] types = exe.GetTypes();
            System.Type zoType = exe.GetType(nameOfZeichenobjekt);

            this._KWahl = new Konstruktorauswahl(zoType);
            this._KWahl.ShowDialog();
            this.Visible = false;
            this._IsInputValid = true;
        }

        /// <summary>
        /// bricht Eingabe ab und kehrt zu vorherigem Dialog zurück
        /// </summary>
        /// <param name="sender">Wird nur von Button aufgerufen</param>
        /// <param name="e">Wird nur von Button aufgerufen</param>
        private void Btn_cancel_Click(object sender, EventArgs e)
        {
            this._IsInputValid = false;
            this.Visible = false;
        }

        /// <summary>
        /// Getter für IsInputValid
        /// </summary>
        /// <returns>wenn Eingabe valide -> true</returns>
        public Boolean GetIsInputValid()
        {
            return this._IsInputValid;
        }
    }
}
