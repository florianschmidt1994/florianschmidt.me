﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Input;
using NamespaceZeichenobjekt;


namespace NamespaceZeichenobjekt
{
    /// <summary>
    /// Klasse zur dynamischen Darstellung der für die Konstruktoren der Zeichenobjekte benötigten Eingabefelder der Parameter
    /// </summary>
    public partial class ParameterValueDialog : Form
    {
        /// <summary>
        /// Konstruktor, für den das Form ist
        /// </summary>
        protected System.Reflection.ConstructorInfo _Constructor;

        /// <summary>
        /// Parameter Lists -> Objektliste
        /// </summary>
        protected Object[] _ParameterValues;

        /// <summary>
        /// Liste der Eingabefelder
        /// </summary>
        private List<ParameterInput> _Inputs;

        /// <summary>
        /// Name es Objekts
        /// </summary>
        protected String _TypedName;

        /// <summary>
        /// Eingabebox für Name des Objekts
        /// </summary>
        protected TextBox _TxtName;

        /// <summary>
        /// Eingaben alle gültig und Dialog abgeschlossen?
        /// </summary>
        protected Boolean _IsInputValid;

        /// <summary>
        /// Panel auf dem die Eingabefelder abgelegt werden
        /// </summary>
        protected Panel _MyDockPanel;

        /// <summary>
        /// Konstruktor für den Dialog
        /// </summary>
        /// <param name="constructor">Konstruktor für den der Dialog aufgebaut werden soll</param>
        public ParameterValueDialog(System.Reflection.ConstructorInfo constructor)
        {
            this.SuspendLayout();
            Int16 y = 0;

            //liest Parameter aus gegebenem Konstruktor aus
            System.Reflection.ParameterInfo[] parInfos = constructor.GetParameters();
            Type[] parTypes = new Type[parInfos.Length];
            String[] _parNames = new String[parInfos.Length];
            _parNames.Initialize();

            //überführt von System.Reflection vorgegebene Datenstruktur in Array von Type und Array von String
            foreach (System.Reflection.ParameterInfo p in parInfos)
            {
                parTypes[y] = p.ParameterType;
                _parNames[y] = p.Name;
                y++;
            }
            InitializeComponent();
            this._Constructor = constructor;

            //initiale Angabe der Größe des Fensters
            SetBounds(100, 100, 450, 98);

            this.Text = "Parameterwerte eingeben:";
            this._MyDockPanel = new Panel();
            this.Controls.Add(this._MyDockPanel);

            this._MyDockPanel.Dock = System.Windows.Forms.DockStyle.Top;

            this._Inputs = new List<ParameterInput>();


            //Eingabefeld für Objektname
            Label lblName = new Label();
            lblName.Text = "Name";
            lblName.Location = new System.Drawing.Point(20, 45 - 26);
            this._MyDockPanel.Controls.Add(lblName);
            this._TxtName = new TextBox();
            this._TxtName.Location = new System.Drawing.Point(160, 45 - 26);
            this._MyDockPanel.Controls.Add(this._TxtName);

            //Darstellung alle Eingabefelder für Konstruktor
            if (parTypes != null)
            {
                String[] parNames = _parNames;
                if (parNames != null && parTypes.Length != parNames.Length)
                    parNames = null;

                /* 
                 * lege Label und Eingabefelder an
                 * dabei wird auf der entsprechende ParameterInput typ gesucht
                 * dieser gibt dann das zugehörige Label und Eingabefeld in die Liste inputs 
                 */
                for (int i = 0; i < parTypes.Length; i++)
                    if (parNames != null)
                        this._Inputs.Add(ParameterInput.AddLabelInput(parTypes[i], parNames[i]));
                    else
                        this._Inputs.Add(ParameterInput.AddLabelInput(parTypes[i], null));

                int n = 0;
                /*
                 * Darstellen der in inputs aufgelisteten Labels und Eingabefelder
                */
                foreach (ParameterInput p in this._Inputs)
                {
                    for (int i = 0; i < p.GetLabels().Count(); i++)
                    {
                        Label l = p.GetLabels()[i];
                        //Positionsangaben der Labels und Inputs
                        // alle 26px kommt eine Zeile
                        l.Location = new System.Drawing.Point(20, 45 + 26 * n);
                        //die Elemente werden dem Panel hinzugefügt
                        this._MyDockPanel.Controls.Add(l);
                        Control c = p.GetInputs()[i];
                        c.Location = new System.Drawing.Point(160, 45 + 26 * n);
                        this._MyDockPanel.Controls.Add(c);
                        n++;
                    }
                }
                this._MyDockPanel.Size = new System.Drawing.Size(450, 48 + 26 * n);
                SetBounds(100, 100, 450, 120 + 26 * n);
                this._ParameterValues = new Object[parTypes.Length];
            }
            else
            {
                this._ParameterValues = new Object[0];
            }
            FlowLayoutPanel buttonPane = new FlowLayoutPanel();
            buttonPane.Dock = System.Windows.Forms.DockStyle.Bottom;
            buttonPane.Size = new System.Drawing.Size(450, 30);
            buttonPane.FlowDirection = FlowDirection.LeftToRight;

            //OK Button
            Button okButton = new Button();
            okButton.Text = "OK";
            okButton.Location = new System.Drawing.Point(120, 145);
            okButton.Size = new System.Drawing.Size(195, 23);
            //Methode für OK Button
            okButton.Click += delegate(System.Object o, System.EventArgs e)
            {
                try
                {
                    this._TypedName = this._TxtName.Text;
                    if (this._TypedName == null || this._TypedName.Equals(""))
                        this._TypedName = "unbenannt";
                    int i = 0;
                    //Jedes Eingabefeld wird ausgelesen und der eingegebene Wert in parameterValues gespeichert
                    foreach (ParameterInput p in this._Inputs)
                    {
                        this._ParameterValues[i++] = p.GetValue();
                    }

                    this._IsInputValid = true;
                    //Modaler Dialog kehrt zurück
                    this.Visible = false;
                }
                catch
                {
                    this._IsInputValid = false;
                }
            };
            buttonPane.Controls.Add(okButton);

            Button cancelButton = new Button();
            cancelButton.Text = "Cancel";
            cancelButton.Click += delegate(System.Object o, System.EventArgs e)
            {
                this._IsInputValid = false;
                this.Visible = false;
            };

            buttonPane.Controls.Add(cancelButton);
            this.Controls.Add(buttonPane);
            this.Refresh();
            this.ResumeLayout(false);
            this.PerformLayout();
        }
        
        /// <summary>
        /// Getter für den zu verwendenden Konstruktor
        /// </summary>
        /// <returns>Konstruktor mit für den in diesem Dialog Daten eingegeben werden sollten</returns>
        public System.Reflection.ConstructorInfo GetConstructor()
        {
            return this._Constructor;
        }
        
        /// <summary>
        /// Getter für den Namen des zu erzeugenden Objekts
        /// </summary>
        /// <returns>Name</returns>
        public String GetTypedName()
        {
            return this._TypedName;
        }

        /// <summary>
        /// Getter für die Parameter
        /// </summary>
        /// <returns>ein Array von Objects, die alle eingegebenen Parameter enthalten</returns>
        public Object[] GetParameterValues()
        {
            return this._ParameterValues;
        }

        /// <summary>
        /// Getter für IsInputValid
        /// </summary>
        /// <returns>true, wenn alle Eingaben gültig waren</returns>
        public Boolean GetIsInputValid()
        {
            return this._IsInputValid;
        }
    }
}
