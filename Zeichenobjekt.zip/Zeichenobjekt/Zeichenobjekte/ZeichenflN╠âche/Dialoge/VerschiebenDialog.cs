﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NamespaceZeichenobjekt
{
    /// <summary>
    /// Verschiebendialog, welcher von Form erbt
    /// </summary>
    public partial class VerschiebenDialog : Form
    {
        /// <summary>
        /// Delta in x-Richtung, um den das Objekt verschoben werden soll
        /// </summary>
        protected double _DX;

        /// <summary>
        /// Delta in y-Richtung, um den das Objekt verschoben werden soll
        /// </summary>
        protected double _DY;

        /// <summary>
        /// Eingaben alle gültig und Dialog abgeschlossen?
        /// </summary>
        protected Boolean _IsInputValid;

        /// <summary>
        /// Konstruktor für den Dialog
        /// </summary>
        public VerschiebenDialog()
        {
            InitializeComponent();
        }

        /// <summary>
        /// nimmt Parameter entgegen und lässt ausgewähltes Zeichenobjekt verschieben
        /// </summary>
        /// <param name="sender">Wird nur von Button aufgerufen</param>
        /// <param name="e">Wird nur von Button aufgerufen</param>
        private void Btn_OK_Click(object sender, EventArgs e)
        {
            try
            {
                this._DX = Double.Parse(this.textBox_xRichtung.Text.Replace(',', '.'));
                this._DY = Double.Parse(this.textBox_yRichtung.Text.Replace(',', '.'));
                this._IsInputValid = true;
                this.Visible = false;
            }
            catch
            {
                this._IsInputValid = false;
            }
        }

        /// <summary>
        /// bricht Eingabe ab und kehrt zu vorherigem Dialog zurück
        /// </summary>
        /// <param name="sender">Wird nur von Button aufgerufen</param>
        /// <param name="e">Wird nur von Button aufgerufen</param>
        private void Btn_Cancel_Click(object sender, EventArgs e)
        {
            this.Visible = false;
            this._IsInputValid = false;
        }

        /// <summary>
        /// Getter für Delta x
        /// </summary>
        /// <returns>Delta in x-Richtung, um den das Objekt verschoben werden soll</returns>
        public double GetDX()
        {
            return this._DX;
        }

        /// <summary>
        /// Getter für Delta y
        /// </summary>
        /// <returns>Delta in y-Richtung, um den das Objekt verschoben werden soll</returns>
        public double GetDY()
        {
            return this._DY;
        }

        /// <summary>
        /// Getter für IsInputValid
        /// </summary>
        /// <returns>wenn Eingabe valide -> true</returns>
        public Boolean GetIsInputValid()
        {
            return this._IsInputValid;
        }
    }
}
