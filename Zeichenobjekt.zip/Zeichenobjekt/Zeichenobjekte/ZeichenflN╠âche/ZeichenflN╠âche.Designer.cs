﻿namespace NamespaceZeichenobjekt
{
    partial class Zeichenfläche
    {
        /// <summary>
        /// Erforderliche Designervariable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Verwendete Ressourcen bereinigen.
        /// </summary>
        /// <param name="disposing">True, wenn verwaltete Ressourcen gelöscht werden sollen; andernfalls False.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Vom Windows Form-Designer generierter Code

        /// <summary>
        /// Erforderliche Methode für die Designerunterstützung.
        /// Der Inhalt der Methode darf nicht mit dem Code-Editor geändert werden.
        /// </summary>
        private void InitializeComponent()
        {
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            this.colorDialog2 = new System.Windows.Forms.ColorDialog();
            this.flowLayoutPanel_steuerung = new System.Windows.Forms.FlowLayoutPanel();
            this.Btn_New = new System.Windows.Forms.Button();
            this.btnTurn = new System.Windows.Forms.Button();
            this.btnMove = new System.Windows.Forms.Button();
            this.btn_Scale = new System.Windows.Forms.Button();
            this.btn_delete = new System.Windows.Forms.Button();
            this.flowLayoutPanel_graph = new System.Windows.Forms.FlowLayoutPanel();
            this._ZobjektListModel = new NamespaceZeichenobjekt.StringListModel();
            this.flowLayoutPanel_steuerung.SuspendLayout();
            this.SuspendLayout();
            // 
            // flowLayoutPanel_steuerung
            // 
            this.flowLayoutPanel_steuerung.Controls.Add(this.Btn_New);
            this.flowLayoutPanel_steuerung.Controls.Add(this.btnTurn);
            this.flowLayoutPanel_steuerung.Controls.Add(this.btnMove);
            this.flowLayoutPanel_steuerung.Controls.Add(this.btn_Scale);
            this.flowLayoutPanel_steuerung.Controls.Add(this.btn_delete);
            this.flowLayoutPanel_steuerung.Controls.Add(this._ZobjektListModel);
            this.flowLayoutPanel_steuerung.Dock = System.Windows.Forms.DockStyle.Left;
            this.flowLayoutPanel_steuerung.Location = new System.Drawing.Point(0, 0);
            this.flowLayoutPanel_steuerung.Name = "flowLayoutPanel_steuerung";
            this.flowLayoutPanel_steuerung.Size = new System.Drawing.Size(198, 337);
            this.flowLayoutPanel_steuerung.TabIndex = 27;
            // 
            // Btn_New
            // 
            this.Btn_New.BackgroundImage = global::NamespaceZeichenobjekt.Properties.Resources._new;
            this.Btn_New.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.Btn_New.Location = new System.Drawing.Point(3, 3);
            this.Btn_New.Name = "Btn_New";
            this.Btn_New.Size = new System.Drawing.Size(32, 32);
            this.Btn_New.TabIndex = 34;
            this.Btn_New.UseVisualStyleBackColor = true;
            this.Btn_New.Click += new System.EventHandler(this.Btn_New_Click);
            // 
            // btnTurn
            // 
            this.btnTurn.BackgroundImage = global::NamespaceZeichenobjekt.Properties.Resources.turn;
            this.btnTurn.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnTurn.Location = new System.Drawing.Point(41, 3);
            this.btnTurn.Name = "btnTurn";
            this.btnTurn.Size = new System.Drawing.Size(32, 32);
            this.btnTurn.TabIndex = 35;
            this.btnTurn.UseVisualStyleBackColor = true;
            this.btnTurn.Click += new System.EventHandler(this.BtnTurn_Click);
            // 
            // btnMove
            // 
            this.btnMove.BackgroundImage = global::NamespaceZeichenobjekt.Properties.Resources.move;
            this.btnMove.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnMove.Location = new System.Drawing.Point(79, 3);
            this.btnMove.Name = "btnMove";
            this.btnMove.Size = new System.Drawing.Size(32, 32);
            this.btnMove.TabIndex = 36;
            this.btnMove.UseVisualStyleBackColor = true;
            this.btnMove.Click += new System.EventHandler(this.BtnMove_Click);
            // 
            // btn_Scale
            // 
            this.btn_Scale.BackgroundImage = global::NamespaceZeichenobjekt.Properties.Resources.scale;
            this.btn_Scale.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_Scale.Location = new System.Drawing.Point(117, 3);
            this.btn_Scale.Name = "btn_Scale";
            this.btn_Scale.Size = new System.Drawing.Size(32, 32);
            this.btn_Scale.TabIndex = 37;
            this.btn_Scale.UseVisualStyleBackColor = true;
            this.btn_Scale.Click += new System.EventHandler(this.Btn_Scale_Click);
            // 
            // btn_delete
            // 
            this.btn_delete.BackgroundImage = global::NamespaceZeichenobjekt.Properties.Resources.delete;
            this.btn_delete.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btn_delete.Location = new System.Drawing.Point(155, 3);
            this.btn_delete.Name = "btn_delete";
            this.btn_delete.Size = new System.Drawing.Size(32, 32);
            this.btn_delete.TabIndex = 38;
            this.btn_delete.UseVisualStyleBackColor = true;
            this.btn_delete.Click += new System.EventHandler(this.Btn_delete_Click);
            // 
            // flowLayoutPanel_graph
            // 
            this.flowLayoutPanel_graph.BackColor = System.Drawing.Color.White;
            this.flowLayoutPanel_graph.Dock = System.Windows.Forms.DockStyle.Fill;
            this.flowLayoutPanel_graph.Location = new System.Drawing.Point(198, 0);
            this.flowLayoutPanel_graph.Name = "flowLayoutPanel_graph";
            this.flowLayoutPanel_graph.Size = new System.Drawing.Size(626, 337);
            this.flowLayoutPanel_graph.TabIndex = 28;
            this.flowLayoutPanel_graph.Resize += new System.EventHandler(this.FlowLayoutPanel_graph_Resize);
            // 
            // zobjektListModel
            // 
            this._ZobjektListModel.FormattingEnabled = true;
            this._ZobjektListModel.Location = new System.Drawing.Point(3, 41);
            this._ZobjektListModel.Name = "zobjektListModel";
            this._ZobjektListModel.Size = new System.Drawing.Size(182, 290);
            this._ZobjektListModel.TabIndex = 39;
            // 
            // Zeichenfläche
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(824, 337);
            this.Controls.Add(this.flowLayoutPanel_graph);
            this.Controls.Add(this.flowLayoutPanel_steuerung);
            this.Name = "Zeichenfläche";
            this.Text = "Zeichenfläche";
            this.flowLayoutPanel_steuerung.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ColorDialog colorDialog1;
        private System.Windows.Forms.ColorDialog colorDialog2;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel_steuerung;
        private System.Windows.Forms.Button Btn_New;
        private System.Windows.Forms.Button btnTurn;
        private System.Windows.Forms.Button btnMove;
        private System.Windows.Forms.Button btn_Scale;
        private System.Windows.Forms.Button btn_delete;
        private StringListModel _ZobjektListModel;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel_graph;

    }
}

