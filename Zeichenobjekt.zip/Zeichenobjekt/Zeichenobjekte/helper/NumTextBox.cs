﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace NamespaceZeichenobjekt
{
    /// <summary>
    /// Helferklasse für ein GUI Element für die Eingabe von Doubles
    /// Akzeptiert die Eingabe von Zahlen, ',' und '.'
    /// </summary>
    public class NumTextBox : TextBox
    {
        protected override void OnKeyPress(KeyPressEventArgs e)
        {
            if ((!char.IsDigit(e.KeyChar) && !char.IsControl(e.KeyChar)) && !(e.KeyChar == ',') && !(e.KeyChar == '.'))
                e.Handled = true;

            base.OnKeyPress(e);
        }
    }
}
