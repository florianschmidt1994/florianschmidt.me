﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NamespaceZeichenobjekt.Zeichenobjekte
{
    /// <summary>
    /// Das Polygon als Füllzeichenobjekt mit allem was dazu  gehört
    /// </summary>
    class Polygon : FuellZeichenObjekt
    {

        /// <summary>
        /// Die Punkte des Polygons
        /// </summary>
        private Punkt[] _EckPunkte;

        /// <summary>
        /// Konstruktor für ein Polygon mit einem Array von Punkten als Parameter
        /// </summary>
        /// <param name="punkte">die Punkte des Polygons</param>
        /// <param name="lf">die Farbe, mit der die Umrandung gezeichnet werden soll</param>
        /// <param name="ld">die Dicke der Umrandung</param>
        /// <param name="ff">die Farbe, mit der die Flaeche gefuellt werden soll</param>
        public Polygon(Punkt[] punkte, Color lf, double ld, Color ff)
            : base(lf, ld, ff)
        {

            if (punkte.Length < 3)
                throw new System.ArgumentNullException("Zu wenig Punkte f\u00fcr ein Polygon");
            this._EckPunkte = punkte;
        }

        /// <summary>
        /// Konstruktor für ein Polygon mit einem Array von x- und y-Koordinaten der Punkte als Parameter
        /// </summary>
        /// <param name="xs">die x-Koordinaten der Punkte des Polygons</param>
        /// <param name="ys">die y-Koordinaten der Punkte des Polygons</param>
        /// <param name="lf">die Farbe, mit der die Umrandung gezeichnet werden soll</param>
        /// <param name="ld">die Dicke der Umrandung</param>
        /// <param name="ff">die Farbe, mit der die Flaeche gefuellt werden soll</param>
        public Polygon(double[] xs, double[] ys, Color lf, double ld, Color ff)
            : base(lf, ld, ff)
        {
            int n = Math.Min(xs.Length, ys.Length);
            if (n < 3)
            {
                throw new System.ArgumentNullException("Zu wenig Punkte f\u00fcr ein Polygon");
            }
            this._EckPunkte = new Punkt[n];
            for (int i = 0; i < n; i++)
            {
                this._EckPunkte.SetValue(new Punkt(xs[i], ys[i]), i);
            }
        }

        /// <summary>
        /// see ZeichenObjekte.ZeichenObjekt#darstellen
        /// </summary>
        /// <param name="g">Graphics Objekt auf dem gezeichnet werden soll</param>
        override public void Darstellen(Graphics g)
        {
            int n = this._EckPunkte.Length;
            Pen pen = new Pen(this._LinienFarbe, (float)this._LinienDicke);
            Point[] _punkte = new Point[n];

            for (int i = 0; i < n; i++)
            {
                _punkte.SetValue(new Point((int)this._EckPunkte[i].GetX(), (int)this._EckPunkte[i].GetY()), i);
            }
            g.DrawPolygon(pen, _punkte);

            if (this._FuellFarbe != null)
            {
                Brush brush = new SolidBrush(this._FuellFarbe);
                g.FillPolygon(brush, _punkte);
            }
        }

        /// <summary>
        /// @see ZeichenObjekte.ZeichenObjekt#drehen(ZeichenObjekte.Punkt, double)
        /// </summary>
        /// <param name="umP">Punkt um den gedreht werden soll</param>
        /// <param name="w">Winkel um den gedreht werden soll</param>
        override public void Drehen(Punkt umP, double w)
        {
            int n = this._EckPunkte.Length;
            for (int i = 0; i < n; i++)
            {
                this._EckPunkte[i].Drehen(umP, w);
            }
        }

        /// <summary>
        /// @see ZeichenObjekte.ZeichenObjekt#verschieben(double, double)
        /// </summary>
        /// <param name="dx">x Richtung um die verschoben werden soll</param>
        /// <param name="dy">y Richtung um die verschoben werden soll</param>
        override public void Verschieben(double dx, double dy)
        {
            int n = this._EckPunkte.Length;
            for (int i = 0; i < n; i++)
            {
                this._EckPunkte[i].Verschieben(dx, dy);
            }
        }

        /// <summary>
        /// @see ZeichenObjekte.ZeichenObjekt#strecken(ZeichenObjekte.Punkt, double)
        /// </summary>
        /// <param name="ausP">Bezugspunkt fürs Strecken</param>
        /// <param name="f">Faktor um den gestreckt werden soll</param>
        override public void Strecken(Punkt ausP, double f)
        {
            int n = this._EckPunkte.Length;
            for (int i = 0; i < n; i++)
            {
                this._EckPunkte[i].Strecken(ausP, f);
            }
            if (f > 0.0)
                this._LinienDicke *= f;
        }
    }
}
