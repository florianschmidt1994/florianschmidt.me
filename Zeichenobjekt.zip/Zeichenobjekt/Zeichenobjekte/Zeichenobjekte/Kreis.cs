﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NamespaceZeichenobjekt.Zeichenobjekte
{
    /// <summary>
    /// Der Kreis als Füllzeichenobjekt mit allem was dazu  gehört
    /// </summary>
    class Kreis : FuellZeichenObjekt
    {
        /// <summary>
        /// der Mittelpunkt des Kreises
        /// </summary>
        private Punkt _MittelPunkt;

        /// <summary>
        /// der Radius des Kreises
        /// </summary>
        private double _Radius;

        /// <summary>
        /// Konstruktor für einen Kreis mit einem Punkt als Parameter
        /// </summary>
        /// <param name="mp">der Mittelpunkt des Kreises</param>
        /// <param name="r">der Radius des Kreises</param>
        /// <param name="lf">die Farbe, mit der die Umrandung gezeichnet werden soll</param>
        /// <param name="ld">die Dicke der Umrandung</param>
        /// <param name="ff">die Farbe, mit der die Flaeche gefuellt werden soll</param>
        public Kreis(Punkt mp, double r, Color lf, double ld, Color ff)
            : base(lf, ld, ff)
        {
            this._MittelPunkt = mp;
            if (r <= 0.0)
                this._Radius = 1.0;
            this._Radius = r;
        }


        /// <summary>
        /// Konstruktor für einen Kreis mit x- und y-Koordinate als Parameter
        /// </summary>
        /// <param name="x">x Koordinate des Mittelpunkt des Kreises</param>
        /// <param name="y">y Koordinate des Mittelpunkt des Kreises</param>
        /// <param name="r">der Radius des Kreises</param>
        /// <param name="lf">die Farbe, mit der die Umrandung gezeichnet werden soll</param>
        /// <param name="ld">die Dicke der Umrandung</param>
        /// <param name="ff">die Farbe, mit der die Flaeche gefuellt werden soll</param>
        public Kreis(double x, double y, double r, Color lf, double ld, Color ff)
            : base(lf, ld, ff)
        {
            this._MittelPunkt = new Punkt(x, y);
            if (r <= 0.0)
                this._Radius = 1.0;
            this._Radius = r;
        }

        /// <summary>
        /// see ZeichenObjekte.ZeichenObjekt#darstellen
        /// </summary>
        /// <param name="g">Graphics Objekt auf dem gezeichnet werden soll</param>
        override public void Darstellen(Graphics g)
        {
            if (this._FuellFarbe != null)
            {
                Brush brush = new SolidBrush(this._FuellFarbe);
                //TODO Mittelpunkt ist bei g.DrawEllipse nicht der Mittelpunkt
                //g.FillEllipse(brush, (int)(this.mittelPunkt.X), (int)(this.mittelPunkt.Y), (int)(2 * (this.radius)), (int)(2 * (this.radius)));
                g.FillEllipse(brush, (float)(this._MittelPunkt.GetX() - this._Radius), (float)(this._MittelPunkt.GetY() - this._Radius), (float)(2 * this._Radius), (float)(2 * this._Radius));
            }
            Pen pen = new Pen(this._LinienFarbe, (float)this._LinienDicke);
            g.DrawEllipse(pen, (float)(this._MittelPunkt.GetX() - this._Radius), (float)(this._MittelPunkt.GetY() - this._Radius), (float)(2 * this._Radius), (float)(2 * this._Radius));
        }

        /// <summary>
        /// @see ZeichenObjekte.ZeichenObjekt#drehen(ZeichenObjekte.Punkt, double)
        /// </summary>
        /// <param name="umP">Punkt um den gedreht werden soll</param>
        /// <param name="w">Winkel um den gedreht werden soll</param>
        override public void Drehen(Punkt umP, double w)
        {
            this._MittelPunkt.Drehen(umP, w);
        }

        /// <summary>
        /// @see ZeichenObjekte.ZeichenObjekt#verschieben(double, double)
        /// </summary>
        /// <param name="dx">x Richtung um die verschoben werden soll</param>
        /// <param name="dy">y Richtung um die verschoben werden soll</param>
        override public void Verschieben(double dx, double dy)
        {
            this._MittelPunkt.Verschieben(dx, dy);
        }

        /// <summary>
        /// @see ZeichenObjekte.ZeichenObjekt#strecken(ZeichenObjekte.Punkt, double)
        /// </summary>
        /// <param name="ausP">Bezugspunkt fürs Strecken</param>
        /// <param name="f">Faktor um den gestreckt werden soll</param>
        override public void Strecken(Punkt ausP, double f)
        {
            this._MittelPunkt.Strecken(ausP, f);
            this._Radius *= f;
            if (f > 0.0)
                this._LinienDicke *= f;
        }
    }
}
