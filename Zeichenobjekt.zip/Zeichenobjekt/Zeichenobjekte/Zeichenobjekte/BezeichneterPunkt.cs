﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NamespaceZeichenobjekt.Zeichenobjekte;

namespace NamespaceZeichenobjekt.Zeichenobjekte
{
    /// <summary>
    /// der bezeichnete Punkt mit allem was dazu gehört
    /// </summary>
    class BezeichneterPunkt : ZeichenObjekt
    {
        /// <summary>
        /// der Punkt um den es hier geht
        /// </summary>
        private Punkt _Punkt;

        /// <summary>
        /// die Bezeichnung
        /// </summary>
        private String _Bezeichnung;

        /// <summary>
        /// Konstruktor für einen Bezeichneten Punkt
        /// </summary>
        /// <param name="bez">die Bezeichung des Punktes</param>
        /// <param name="p">der Punkt</param>
        /// <param name="lf"> die Farbe, mit der die Umrandung gezeichnet werden soll</param>
        /// <param name="ld"> die Dicke der Umrandung</param>
        public BezeichneterPunkt(String bez, Punkt p, Color lf, double ld)
            : base(lf, ld)
        {

            this._Bezeichnung = bez;
            this._Punkt = p;
        }

        /// <summary>
        /// Konstruktor für einen Bezeichneten Punkt
        /// </summary>
        /// <param name="bez">die Bezeichung des Punktes</param>
        /// <param name="x">x-Koordinate des Punktes</param>
        /// <param name="y">y-Koordinate des Punktes</param>
        /// <param name="lf">die Farbe, mit der die Umrandung gezeichnet werden soll</param>
        /// <param name="ld">die Dicke der Umrandung</param>
        public BezeichneterPunkt(String bez, double x, double y, Color lf, double ld) : this(bez, new Punkt(x, y), lf, ld) { }

        /// <summary>
        /// see ZeichenObjekte.ZeichenObjekt#darstellen
        /// </summary>
        /// <param name="g">Graphics Objekt auf dem gezeichnet werden soll</param>
        override public void Darstellen(Graphics g)
        {
            Pen pen = new Pen(this._LinienFarbe, (float)this._LinienDicke);
            g.DrawLine(pen, (int)this._Punkt.GetX() - 2, (int)this._Punkt.GetY() - 2, (int)this._Punkt.GetX() + 2, (int)this._Punkt.GetY() + 2);
            g.DrawLine(pen, (int)this._Punkt.GetX() - 2, (int)this._Punkt.GetY() + 2, (int)this._Punkt.GetX() + 2, (int)this._Punkt.GetY() - 2);

            Font font = new Font("Arial", 8, GraphicsUnit.Pixel);
            Brush brush = new SolidBrush(this._LinienFarbe);
            g.DrawString(this._Bezeichnung, font, brush, (int)this._Punkt.GetX() + 3, (int)this._Punkt.GetY() +3);
        }

        /// <summary>
        /// @see ZeichenObjekte.ZeichenObjekt#drehen(ZeichenObjekte.Punkt, double)
        /// </summary>
        /// <param name="umP">Punkt um den gedreht werden soll</param>
        /// <param name="w">Winkel um den gedreht werden soll</param>
        override public void Drehen(Punkt umP, double w)
        {
            this._Punkt.Drehen(umP, w);
        }

        /// <summary>
        /// @see ZeichenObjekte.ZeichenObjekt#verschieben(double, double)
        /// </summary>
        /// <param name="dx">x Richtung um die verschoben werden soll</param>
        /// <param name="dy">y Richtung um die verschoben werden soll</param>
        override public void Verschieben(double dx, double dy)
        {
            this._Punkt.Verschieben(dx, dy);
        }

        /// <summary>
        /// @see ZeichenObjekte.ZeichenObjekt#strecken(ZeichenObjekte.Punkt, double)
        /// </summary>
        /// <param name="ausP">Bezugspunkt fürs Strecken</param>
        /// <param name="f">Faktor um den gestreckt werden soll</param>
        override public void Strecken(Punkt ausP, double f)
        {
            if (f > 0.0)
                this._LinienDicke *= f;
            this._Punkt.Strecken(ausP, f);
        }
    }}
