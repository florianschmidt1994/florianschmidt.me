﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NamespaceZeichenobjekt.Zeichenobjekte
{
    /// <summary>
    /// Abstrakte Klasse aller Füllzeichenobjekte
    /// </summary>
    abstract class FuellZeichenObjekt : ZeichenObjekt
    {
        /// <summary>
        /// die Farbe, mit der die Flaeche gefuellt werden soll
        /// </summary>
        protected Color _FuellFarbe;

        /// <summary>
        /// Konstruktor für Füllzeichenobjekte
        /// </summary>
        /// <param name="lf">die Farbe, mit der die Umrandung gezeichnet werden soll</param>
        /// <param name="ld">die Dicke der Umrandung</param>
        /// <param name="ff">die Farbe, mit der die Flaeche gefuellt werden soll</param>
        public FuellZeichenObjekt(Color lf, double ld, Color ff)
            : base(lf, ld)
        {

            this._FuellFarbe = ff;
        }

        /// <summary>
        /// Getter für Füllfarbe
        /// </summary>
        /// <returns>gibt die Füllfarbe zurück</returns>
        public Color GetFuellFarbe()
        {
            return this._FuellFarbe;
        }

        /// <summary>
        /// Setter für die Füllfarbe
        /// </summary>
        /// <param name="ff">Füllfarbe, die zu verwenden ist</param>
        public void SetFuellFarbe(Color ff)
        {
            this._FuellFarbe = ff;
        }
    }
}
