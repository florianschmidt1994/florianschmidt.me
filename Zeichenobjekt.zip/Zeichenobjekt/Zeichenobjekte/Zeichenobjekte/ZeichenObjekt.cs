﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NamespaceZeichenobjekt.Zeichenobjekte
{
    /// <summary>
    /// Abstrakte Oberklasse aller Zeichenobjekte
    /// </summary>
    abstract class ZeichenObjekt
    {
        /// <summary>
        /// die Farbe, mit der die Umrandung gezeichnet werden soll
        /// </summary>
        protected Color _LinienFarbe;

        /// <summary>
        /// die Dicke der Umrandung
        /// </summary>
        protected double _LinienDicke;
 
        /// <summary>
        /// Konstruktor für Zeichenobjekte
        /// </summary>
        /// <param name="lf">die Farbe, mit der die Umrandung gezeichnet werden soll</param>
        /// <param name="ld">die Dicke der Umrandung</param>
        public ZeichenObjekt(Color lf, double ld)
        {
            this._LinienFarbe = lf;
            if (ld <= 0.0)
                this._LinienDicke = 1.0;

            this._LinienDicke = ld;
        }


        /// <summary>
        /// Zeichnet das Objekt auf eine Zeichenflaeche
        /// </summary>
        /// <param name="g">die Graphik, in der das Objekt gezeichnet werden soll</param>
        public abstract void Darstellen(Graphics g);

        /// <summary>
        /// Dreht das Objekt um den Punkt umP um den Winkel w
        /// </summary>
        /// <param name="umP">Punkt um den gedreht werden soll</param>
        /// <param name="w">Winkel um den gedreht werden soll</param>
        public abstract void Drehen(Punkt umP, double w);

        /// <summary>
        /// Verschiebt das Objekt
        /// </summary>
        /// <param name="dx">x Richtung um die verschoben werden soll</param>
        /// <param name="dy">y Richtung um die verschoben werden soll</param>
        public abstract void Verschieben(double dx, double dy);

        /// <summary>
        /// Streckt das Objekt um das Zentrum ausP und den Faktor f
        /// </summary>
        /// <param name="ausP">Bezugspunkt fürs Strecken</param>
        /// <param name="f">Faktor um den gestreckt werden soll</param>
        public abstract void Strecken(Punkt ausP, double f);

    }
}
