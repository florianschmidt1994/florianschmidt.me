﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace NamespaceZeichenobjekt.Zeichenobjekte
{
    /// <summary>
    /// Ein Punkt, der nicht dargestellt werden kann
    /// </summary>
    class Punkt
    {
        /// <summary>
        /// x-Koordinate des Punktes
        /// </summary>
        private double _X;

        /// <summary>
        /// Getter für die x-Koordinate
        /// </summary>
        /// <returns>x-Koordinate des Punktes</returns>
        public double GetX()
        {
            return _X;
        }

        /// <summary>
        /// Setter für die x-Koordinate
        /// </summary>
        /// <param name="x">zu setzende x-Koordinate</param>
        public void SetX(double x)
        {
            this._X = x;
        }

        /// <summary>
        /// y-Koordinate des Punktes
        /// </summary>
        private double _Y;

        /// <summary>
        /// Getter für die y-Koordinate
        /// </summary>
        /// <returns>y-Koordinate des Punktes</returns>
        public double GetY()
        {
            return _Y;
        }

        /// <summary>
        /// Setter für die y-Koordinate
        /// </summary>
        /// <param name="y">zu setzende y-Koordinate</param>
        public void SetY(double y)
        {
            this._Y = y;
        }

        /// <summary>
        /// Konstruktor für einen Punkt - Erstellt einen Punkt
        /// </summary>
        /// <param name="_x"> x-Koordinate</param>
        /// <param name="_y">y-Koordinate</param>
        public Punkt(double _x, double _y)
        {
            this._X = _x;
            this._Y = _y;
        }

        /// <summary>
        /// Dreht das Objekt um den Punkt umP um den Winkel w
        /// </summary>
        /// <param name="umP">das Drehzentrum</param>
        /// <param name="w">der Winkel in rad (math positive Richtung / gegen den Uhrzeigersinn)</param>
        public void Drehen(Punkt umP, double w)
        {
            double r = Abstand(umP);
            if (r == 0.0)
                return;

            double wz;
            if (umP.GetX() == this._X)
                // tan == oo --> 90/270
                wz = w + (this._Y > umP.GetY() ? 1 : 3) * Math.PI / 2;
            else
                if (this._X > umP.GetX())
                    wz = w + Math.Atan((this._Y - umP.GetY()) / (this._X - umP.GetX()));
                else
                    wz = w + Math.Atan((this._Y - umP.GetY()) / (this._X - umP.GetX())) + Math.PI;
            this._X = umP.GetX() + r * Math.Cos(wz);
            this._Y = umP.GetY() + r * Math.Sin(wz);
        }

        /// <summary>
        /// Verschiebt das Objekt
        /// </summary>
        /// <param name="dx">x-Richtung</param>
        /// <param name="dy">y-Richtung</param>
        public void Verschieben(double dx, double dy)
        {
            this._X += dx;
            this._Y += dy;
        }

        /// <summary>
        /// Streckt das Objekt um das Zentrum ausP und den Faktor f
        /// </summary>
        /// <param name="ausP">das Streckzentrum</param>
        /// <param name="f">der Faktor (>0)</param>
        public void Strecken(Punkt ausP, double f)
        {
            this._X = ausP.GetX() + f * (this._X - ausP.GetX());
            this._Y = ausP.GetY() + f * (this._Y - ausP.GetY());
        }

        /// <summary>
        /// Berechnet den Abstand zwischen diesem und einen anderem Punkt
        /// </summary>
        /// <param name="p">der andere Punkt</param>
        /// <returns>der Abstand</returns>
        public double Abstand(Punkt p)
        {
            if (p == null)
                return 0.0F;
            double dx = this._X - p.GetX();
            double dy = this._Y - p.GetY();
            return Math.Sqrt(dx * dx + dy * dy);
        }
    }
}
