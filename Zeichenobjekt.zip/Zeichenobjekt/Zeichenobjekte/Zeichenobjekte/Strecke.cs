﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using NamespaceZeichenobjekt.Zeichenobjekte;

namespace NamespaceZeichenobjekt.Zeichenobjekte
{
    /// <summary>
    /// Die Strecke als Zeichenobjekt mit allem was dazu gehört
    /// </summary>
    class Strecke : ZeichenObjekt
    {

        /// <summary>
        /// der Startpunkt
        /// </summary>
        private Punkt _StartPunkt;

        /// <summary>
        /// der Endpunkt
        /// </summary>
        private Punkt _EndPunkt;
       
        /// <summary>
        /// Konstruktor einer Stecker mit zwei Punkten als Parameter
        /// </summary>
        /// <param name="sP">der Startpunkt</param>
        /// <param name="eP">der Endpunkt</param>
        /// <param name="lf">die Farbe, mit der die Umrandung gezeichnet werden soll</param>
        /// <param name="ld">die Dicke der Umrandung</param>
        public Strecke(Punkt sP, Punkt eP, Color lf, double ld)
            : base(lf, ld)
        {
            this._StartPunkt = sP;
            this._EndPunkt = eP;
        }

        /// <summary>
        /// Konstruktor einer Stecker mit zwei x- und zwei y-Koordinaten als Parameter
        /// </summary>
        /// <param name="x1">x-Koordinate des Startpunktes</param>
        /// <param name="y1">y-Koordinate des Startpunktes</param>
        /// <param name="x2">x-Koordinate des Endpunktes</param>
        /// <param name="y2">y-Koordinate des Endpunktes</param>        
        /// <param name="eP">der Endpunkt</param>
        /// <param name="lf">die Farbe, mit der die Umrandung gezeichnet werden soll</param>
        /// <param name="ld">die Dicke der Umrandung</param>
        public Strecke(double x1, double y1, double x2, double y2, Color lf, double ld)
            : base(lf, ld)
        {
            this._StartPunkt = new Punkt(x1, y1);
            this._EndPunkt = new Punkt(x2, y2);
        }

        /// <summary>
        /// see ZeichenObjekte.ZeichenObjekt#darstellen
        /// </summary>
        /// <param name="g">Graphics Objekt auf dem gezeichnet werden soll</param>
        override public void Darstellen(Graphics g)
        {
            Pen pen = new Pen(this._LinienFarbe, (float)this._LinienDicke);
            g.DrawLine(pen, (int)this._StartPunkt.GetX(), (int)this._StartPunkt.GetY(), (int)this._EndPunkt.GetX(), (int)this._EndPunkt.GetY());
        }

        /// <summary>
        /// @see ZeichenObjekte.ZeichenObjekt#drehen(ZeichenObjekte.Punkt, double)
        /// </summary>
        /// <param name="umP">Punkt um den gedreht werden soll</param>
        /// <param name="w">Winkel um den gedreht werden soll</param>
        override public void Drehen(Punkt umP, double w)
        {
            this._StartPunkt.Drehen(umP, w);
            this._EndPunkt.Drehen(umP, w);
        }

        /// <summary>
        /// @see ZeichenObjekte.ZeichenObjekt#verschieben(double, double)
        /// </summary>
        /// <param name="dx">x Richtung um die verschoben werden soll</param>
        /// <param name="dy">y Richtung um die verschoben werden soll</param>
        override public void Verschieben(double dx, double dy)
        {
            this._StartPunkt.Verschieben(dx, dy);
            this._EndPunkt.Verschieben(dx, dy);
        }

        /// <summary>
        /// @see ZeichenObjekte.ZeichenObjekt#strecken(ZeichenObjekte.Punkt, double)
        /// </summary>
        /// <param name="ausP">Bezugspunkt fürs Strecken</param>
        /// <param name="f">Faktor um den gestreckt werden soll</param>
        override public void Strecken(Punkt ausP, double f)
        {
            this._StartPunkt.Strecken(ausP, f);
            this._EndPunkt.Strecken(ausP, f);
            if (f > 0.0)
                this._LinienDicke *= f;
        }
    }
}
